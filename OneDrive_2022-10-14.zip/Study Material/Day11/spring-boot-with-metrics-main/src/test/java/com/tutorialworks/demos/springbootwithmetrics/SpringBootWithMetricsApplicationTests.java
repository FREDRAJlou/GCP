package com.tutorialworks.demos.springbootwithmetrics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWithMetricsApplicationTests {

	@Test
	void contextLoads() {
	}

}
